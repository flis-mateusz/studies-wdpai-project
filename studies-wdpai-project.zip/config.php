<?php

const USERNAME = 'admin';
const PASSWORD = 'm3rLIUVnS8GisXjReE3AlIs';
const HOST = 'server.lan';
const DATABASE = 'wdpai';



